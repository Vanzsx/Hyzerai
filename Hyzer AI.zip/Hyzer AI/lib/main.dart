import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/chat_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hyzer AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B0C0E),
        primaryColor: const Color(0xFF6366F1),
        useMaterial3: true,
      ),
      home: const MainWrapper(),
    );
  }
}

class MainWrapper extends StatefulWidget {
  const MainWrapper({super.key});

  @override
  State<MainWrapper> createState() => _MainWrapperState();
}

class _MainWrapperState extends State<MainWrapper> {
  String? _token;

  @override
  Widget build(BuildContext context) {
    // Kalau belum login, tampilin halaman Login
    if (_token == null) {
      return LoginScreen(
        onLoginSuccess: (token) {
          setState(() => _token = token);
        },
      );
    }

    // Kalau udah login, langsung masuk ke Chat AI
    return const ChatScreen();
  }
}