import 'dart:convert';
import 'package:http/http.dart' as http;

class ChatService {
  // Ganti URL ini sesuai endpoint AI lu
  static const String baseUrl = "https://api.hyzerai.my.id/v1/chat";
  
  // Kalau butuh API key, taruh di sini
  static const String apiKey = "hzr_test_xxxxxx"; 

  static Future<String> sendMessage(String prompt) async {
    try {
      final response = await http.post(
        Uri.parse(baseUrl),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $apiKey", // Hapus kalau gak butuh
        },
        body: jsonEncode({
          "model": "hyzer-1",
          "messages": [
            {"role": "user", "content": prompt}
          ]
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        // Sesuaikan dengan format response backend lu
        return data['choices'][0]['message']['content'] ?? "Gagal membaca balasan.";
      } else {
        return "Error: ${response.statusCode} - ${response.body}";
      }
    } catch (e) {
      return "Koneksi error: $e";
    }
  }
}